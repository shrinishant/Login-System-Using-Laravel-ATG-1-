<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class atgtaskf extends Model
{
    protected $primaryKey = 'email';
    // protected $primaryKey = 'id';
    protected $fillable = ['username','email','password'];
    use HasFactory;
}
