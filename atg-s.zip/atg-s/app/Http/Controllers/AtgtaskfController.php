<?php

namespace App\Http\Controllers;

use App\Models\atgtaskf;
use Illuminate\Http\Request;

class AtgtaskfController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }

    public function dash(Request $request){

        if(!$request->session()->has($request->session()->get('uname'))){
            // echo "yes";
            return view('dashboard', array('uname' => $request->session()->get('uname')));
        }else{
            // echo "no";
            $request->session()->forget('uname');
            return view('atg_login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('atg-task-1');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $res = new atgtaskf;

        $res->username=$request->input('username');
        $res->email = $request->input('email');
        $res->password = $request->input('password');

        $res->save();

        // $request->session()->flash('msg', 'Inserted Successfully');
    }

    public function login(Request $request)
    {

        $res = atgtaskf::where("email", $request->input('email'))->get();
        // echo $res[0]->password;
        $uname = $res[0]->username;
        // echo $uname;

        if($request -> input('password') == $res[0]->password){
            $request->session()->put('uname', $uname);
            echo "successfull";
            return redirect('dashboard_user/');
        }else{
            echo "Please try again";
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\atgtaskf  $atgtaskf
     * @return \Illuminate\Http\Response
     */
    public function show(atgtaskf $atgtaskf)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\atgtaskf  $atgtaskf
     * @return \Illuminate\Http\Response
     */
    public function edit(atgtaskf $atgtaskf)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\atgtaskf  $atgtaskf
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, atgtaskf $atgtaskf)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\atgtaskf  $atgtaskf
     * @return \Illuminate\Http\Response
     */
    public function destroy(atgtaskf $atgtaskf)
    {
        //
    }
}
